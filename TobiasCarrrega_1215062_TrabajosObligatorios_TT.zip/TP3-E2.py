"""
-----------------------------------------------------------------------------------------------
Título: TP03-02 | GENERACIÓN DE MATRICES CON PATRONES (MENÚ) 
Fecha:24/9
Autor: Tobias Carrega

Descripción:
Desarrollar un programa que presente el siguiente menú de opciones: --------------------------- 
MENÚ DEL PROGRAMA            --------------------------- 
[1] Matriz patrón A (diagonal principal) 
[2] matriz patrón B (diagonal secundaria) 
[3] matriz patrón C (triángulo izquierda) 
[4] matriz patrón D (franjas horizontales) 
[5] matriz patrón E (salteado cada 2) 
[6] matriz patrón F (triángulo derecha) --------------------------- 
[0] Salir del programa --------------------------- 
Seleccione una opción: 
Cada opción llamará a una función a desarrollar que deberá generar cada una de las siguientes matrices: 
Luego de llamar a cada función se debe mostrar por pantalla la matriz obtenida. El tamaño de las matrices debe 
establecerse como N x N solicitando el valor por teclado, y las funciones deben servir para cualquier valor ingresado por 
teclado. 

Pendientes:
-----------------------------------------------------------------------------------------------
"""

#----------------------------------------------------------------------------------------------
# MÓDULOS
#----------------------------------------------------------------------------------------------
# No se requieren módulos externos

#----------------------------------------------------------------------------------------------
# FUNCIONES
#----------------------------------------------------------------------------------------------
def matriz_patron_a(N):
    matriz = []
    valor = 1
    for i in range(N):
        fila = []
        for j in range(N):
            if i == j:
                fila.append(valor)
                valor += 2  # como en el ejemplo: 1,3,5,7...
            else:
                fila.append(0)
        matriz.append(fila)
    return matriz

# Función para patrón B (diagonal secundaria)
def matriz_patron_b(N):
    matriz = []
    valor = 1
    for i in range(N):
        fila = []
        for j in range(N):
            if i + j == N - 1:
                fila.append(valor ** 3)  # ejemplo: 1^3,2^3,3^3,...
                valor += 2
            else:
                fila.append(0)
        matriz.append(fila)
    return matriz

# Función para patrón C (triángulo izquierda)
def matriz_patron_c(N):
    matriz = []
    for i in range(N, 0, -1):
        fila = []
        for j in range(N):
            if j <= N - i:
                fila.append(i)
            else:
                fila.append(0)
        matriz.append(fila)
    return matriz

# Función para patrón D (franjas horizontales)
def matriz_patron_d(N):
    matriz = []
    valor = N * 2
    for i in range(N):
        fila = [valor] * N
        matriz.append(fila)
        valor = valor // 2
    return matriz

# Función para patrón E (salteado cada 2)
def matriz_patron_e(N):
    matriz = []
    contador = 1
    for i in range(N):
        fila = []
        for j in range(N):
            # alterna posiciones según fila y columna
            if (i+j) % 2 == 0:
                fila.append(0)
            else:
                fila.append(contador)
                contador += 1
        matriz.append(fila)
    return matriz

def matriz_patron_f(N):
    matriz = []
    total = N*N
    for i in range(N):
        fila = [0]*N
        for j in range(N-1, N-1-i-1, -1):
            fila[j] = total
            total -= 1
        matriz.append(fila)
    return matriz

def imprimir_matriz(matriz):
    for fila in matriz:
        print(" ".join(str(x) for x in fila))

#----------------------------------------------------------------------------------------------
# CUERPO PRINCIPAL
#----------------------------------------------------------------------------------------------
def main():
    while True:
        print("---------------------------")
        print("MENÚ DEL PROGRAMA")
        print("---------------------------")
        print("[1] Matriz patrón A (diagonal principal)")
        print("[2] Matriz patrón B (diagonal secundaria)")
        print("[3] Matriz patrón C (triángulo izquierda)")
        print("[4] Matriz patrón D (franjas horizontales)")
        print("[5] Matriz patrón E (salteado cada 2)")
        print("[6] Matriz patrón F (triángulo derecha)")
        print("[0] Salir del programa")
        print("---------------------------")
        
        opcion = input("Seleccione una opción: ")
        
        if opcion == "0":
            print("Saliendo del programa...")
            break
        
        N = int(input("Ingrese el tamaño N de la matriz: "))
        
        if opcion == "1":
            matriz = matriz_patron_a(N)
        elif opcion == "2":
            matriz = matriz_patron_b(N)
        elif opcion == "3":
            matriz = matriz_patron_c(N)
        elif opcion == "4":
            matriz = matriz_patron_d(N)
        elif opcion == "5":
            matriz = matriz_patron_e(N)
        elif opcion == "6":
            matriz = matriz_patron_f(N)
        else:
            print("Opción inválida. Intente nuevamente.")
            continue
        
        print("Matriz generada:")
        imprimir_matriz(matriz)
        print()  # línea en blanco para separar resultados

# Punto de entrada al programa
if __name__ == "__main__":
    main()
