"""
-----------------------------------------------------------------------------------------------
Título: TP01-07 | FECHA DÍA SIGUIENTE
Fecha:24/9
Autor: Tobias Carrega

Descripción:
Escribir una función fechaDiaSiguiente() que reciba como parámetro una fecha cualquiera expresada por tres enteros 
(correspondientes al día, mes y año) y calcule y devuelva un string (en formato “dd/mm/aaaa”) con la fecha del día 
siguiente a la fecha dada. Para probar la función, escribir un programa que pida los tres datos de una fecha (día, mes y 
año) y, aprovechando la función creada, devuelva la fecha del día siguiente al ingresado. 

Pendientes:
-----------------------------------------------------------------------------------------------
"""

#----------------------------------------------------------------------------------------------
# MÓDULOS
#----------------------------------------------------------------------------------------------
# No se requieren módulos externos

#----------------------------------------------------------------------------------------------
# FUNCIONES
#----------------------------------------------------------------------------------------------
# Definimos la función que recibe día, mes y año
def fechaDiaSiguiente(dia, mes, anio):
    # Lista con la cantidad de días de cada mes (por defecto febrero con 28)
    dias_en_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    # Verificamos si el año es bisiesto (febrero tiene 29 días)
    if (anio % 400 == 0) or (anio % 4 == 0 and anio % 100 != 0):
        dias_en_mes[1] = 29

    # Sumamos un día
    dia += 1

    # Si el día supera el máximo del mes, reiniciamos a 1 y avanzamos de mes
    if dia > dias_en_mes[mes - 1]:
        dia = 1
        mes += 1

        # Si el mes supera 12, reiniciamos a 1 y avanzamos de año
        if mes > 12:
            mes = 1
            anio += 1

    # Devolvemos la fecha como string en formato dd/mm/aaaa
    return f"{dia:02d}/{mes:02d}/{anio}"

#----------------------------------------------------------------------------------------------
# CUERPO PRINCIPAL
#----------------------------------------------------------------------------------------------
def main():
    print("=== CALCULADORA DE FECHA DEL DÍA SIGUIENTE ===")

    # Validamos el ingreso del mes
    m = int(input("Ingrese el mes (1-12): "))
    while m < 1 or m > 12:
        print("⚠️ El mes debe estar entre 1 y 12.")
        m = int(input("Ingrese nuevamente el mes (1-12): "))

    # Validamos el ingreso del día según el mes y si el año es bisiesto
    a = int(input("Ingrese el año: "))

    # Lista provisional de días por mes
    dias_en_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    # Ajustamos febrero si es año bisiesto
    if (a % 400 == 0) or (a % 4 == 0 and a % 100 != 0):
        dias_en_mes[1] = 29

    # Ahora pedimos el día validando según el mes
    d = int(input(f"Ingrese el día (1-{dias_en_mes[m-1]}): "))
    while d < 1 or d > dias_en_mes[m-1]:
        print(f"⚠️ El día debe estar entre 1 y {dias_en_mes[m-1]} para el mes {m}.")
        d = int(input(f"Ingrese nuevamente el día (1-{dias_en_mes[m-1]}): "))

    # Mostramos la fecha siguiente
    print(f"La fecha siguiente a {d:02d}/{m:02d}/{a} es: {fechaDiaSiguiente(d, m, a)}")

# Punto de entrada al programa
main()

