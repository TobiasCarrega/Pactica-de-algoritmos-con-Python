"""
-----------------------------------------------------------------------------------------------
Título: TP02-06 | LISTA NORMALIZADA 
Fecha:24/9
Autor: Tobias Carrega

Descripción:
Escribir una función que reciba una lista de números enteros como parámetro y la normalice, es decir que todos sus 
elementos deben sumar 1.0, respetando las proporciones relativas que cada elemento tiene en la lista original. Desarrollar 
también un programa que permita verificar el comportamiento de la función. Por ejemplo, normalizar([1, 1, 2]) debe 
devolver [0.25, 0.25, 0.50].

Pendientes:
-----------------------------------------------------------------------------------------------
"""

#----------------------------------------------------------------------------------------------
# MÓDULOS
#----------------------------------------------------------------------------------------------
# No se requieren módulos externos

#----------------------------------------------------------------------------------------------
# FUNCIONES
#----------------------------------------------------------------------------------------------
# Función que normaliza una lista de números
def normalizar(lista):
    total = 0
    for x in lista:
        total += x  # sumamos todos los elementos

    if total == 0:  # Evitamos división por cero
        return [0 for _ in lista]

    # Creamos la lista normalizada
    lista_normalizada = []
    for x in lista:
        lista_normalizada.append(x / total)

    return lista_normalizada

#----------------------------------------------------------------------------------------------
# CUERPO PRINCIPAL
#----------------------------------------------------------------------------------------------
def main():
    print("=== NORMALIZADOR DE LISTAS ===")
    # Pedimos al usuario los números separados por espacio
    entrada = input("Ingrese números enteros separados por espacio: ")
    # Convertimos la entrada en lista de enteros
    numeros = []
    for n in entrada.split():
        numeros.append(int(n))

    # Normalizamos la lista
    normalizada = normalizar(numeros)

    # Mostramos el resultado
    print("Lista normalizada:")
    for valor in normalizada:
        print(f"{valor:.2f}", end=" ")
    print()  # línea en blanco

# Punto de entrada al programa
if __name__ == "__main__":
    main()
