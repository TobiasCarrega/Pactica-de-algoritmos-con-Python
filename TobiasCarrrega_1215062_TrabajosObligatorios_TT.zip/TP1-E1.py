"""
-----------------------------------------------------------------------------------------------
Título: TP01-01 | SEGUNDOS A HORAS:MINUTOS:SEGUNDOS 
Fecha:24/9
Autor: Tobias Carrega

Descripción:
Desarrollar una función que reciba un valor correspondiente a una cantidad de segundos obtenidos de una máquina que 
mide la cantidad de tiempo en ejecutarse un proceso. La función debe convertir dicho valor en horas, minutos y segundos 
y devolver el resultado en un string de la forma “hh:mm:ss”. Por ejemplo, 32130 segundos corresponden a “8:55:30”.

Pendientes:
-----------------------------------------------------------------------------------------------
"""

#----------------------------------------------------------------------------------------------
# MÓDULOS
#----------------------------------------------------------------------------------------------
# No se requieren módulos externos

#----------------------------------------------------------------------------------------------
# FUNCIONES
#----------------------------------------------------------------------------------------------
def convertir_a_horas(segundos):
    # Calculamos la cantidad de horas usando división entera
    horas = segundos // 3600
    # Calculamos los minutos restantes
    minutos = (segundos % 3600) // 60
    # Calculamos los segundos restantes
    seg_restantes = segundos % 60

    # Armamos el string en formato hh:mm:ss usando f-string
    resultado = f"{horas:02d}:{minutos:02d}:{seg_restantes:02d}"

    # Devolvemos el string resultante
    return resultado

#----------------------------------------------------------------------------------------------
# CUERPO PRINCIPAL
#----------------------------------------------------------------------------------------------
def main():
    # Pedimos al usuario que ingrese la cantidad de segundos
    segundos_ingresados = int(input("Ingrese la cantidad de segundos a convertir: "))

    # Mostramos el resultado de manera intuitiva
    print(f"La conversión de {segundos_ingresados} segundos es: {convertir_a_horas(segundos_ingresados)}")

# Punto de entrada al programa
main()

